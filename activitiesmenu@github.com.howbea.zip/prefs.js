// SPDX-FileCopyrightText: 2020 Florian Müllner <fmuellner@gnome.org>
// SPDX-FileCopyrightText: 2024 Yoshiki Takahashi <m32rncsz@gmail.com>
//
// SPDX-License-Identifier: GPL-2.0-or-later

// -*- mode: js2; indent-tabs-mode: nil; js2-basic-offset: 4 -*-

// we use async/await here to not block the mainloop, not to parallelize
/* eslint-disable no-await-in-loop */

import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Gtk from 'gi://Gtk';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

const OptionsGroup = GObject.registerClass(
class OptionsGroup extends Adw.PreferencesGroup {
    _init(settings) {
        super._init({ title: 'Preferences' });

        //settings = this.ExtensionUtils.getSettings();
        
        const Switch = new Gtk.Switch({
            valign: Gtk.Align.CENTER,
        });
        settings.bind('show-avatar',
            Switch, 'active',
            Gio.SettingsBindFlags.DEFAULT);

        const row = new Adw.ActionRow({
            title: 'Avatar',
            activatable_widget: Switch,
        });
        row.add_suffix(Switch);
        this.add(row);
        
        const Switch2 = new Gtk.Switch({
            valign: Gtk.Align.CENTER,
        });
        settings.bind('show-recent-items',
            Switch2, 'active',
            Gio.SettingsBindFlags.DEFAULT);

        const row2 = new Adw.ActionRow({
            title: 'Recent Items',
            activatable_widget: Switch2,
        });
        row2.add_suffix(Switch2);
        this.add(row2);
    }
});

export default class UserThemePrefs extends ExtensionPreferences {
    fillPreferencesWindow(window) {
    const settings = this.getSettings();
    const page = new Adw.PreferencesPage();
    const optionsgroup = new OptionsGroup(settings);
    page.add(optionsgroup);
    window.add(page);
    }
}
